// --------------validation----------------

function validate() {
  var name = document.getElementById("username").value;
  var Email = document.getElementById("email").value;
  var Password = document.getElementById("password").value;
  var Age = document.getElementById("age").value;
  var Phone = document.getElementById("phone").value;
  var neighbourhood = document.getElementById("neighbourhood").value;

  if (name.length == 0) {
    const error= document.getElementById("error2").innerHTML = "Name is required";
    return false;
  }


  if (Email.length == 0) {
    document.getElementById("error3").innerHTML = "email is required";
    return false;
  }

  if (Password.length == 0) {
    document.getElementById("error4").innerHTML = "password is required";
    return false;
  }

  if (Age.length == 0) {
    document.getElementById("error5").innerHTML = "age is required";
    return false;
  }
  
  if (Phone.length == 0) {
    document.getElementById("error6").innerHTML = "phone is required";
    return false;
  }
  

  if (neighbourhood.length == 0) {
    document.getElementById("error7").innerHTML = "neighbourhood is must be 10 digits";
    return false;
  }


  
}

const btn_menu = document.getElementById("menu_btn");
const cross_btn = document.getElementById("btn_cross");
const sidebar1 = document.getElementById("sidebar");

btn_menu.addEventListener("click", () => {
  sidebar1.classList.add("active");
});

cross_btn.addEventListener("click", () => {
  sidebar1.classList.remove("active");
});


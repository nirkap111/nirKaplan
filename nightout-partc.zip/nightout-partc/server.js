const express = require("express");
const bodyParser = require("body-parser");
const app = express();
var sql = require('./db')
const CRUD_operations = require("./CRUD_functions.js");
var path = require('path');
app.use(express.static(__dirname))
// Create a route for getting all customers

// parse requests of content-type: application/json
app.use(bodyParser.json());
// parse requests of content-type: application/x-www-form-urlencoded
app.use(bodyParser.urlencoded({
    extended: true
}));
// simple route
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, "index.html"))
});
app.get('/login', (req, res) => {

    res.sendFile(path.join(__dirname, "login.html"))
})
// Get All customers
app.get("/customers", function (req, res) {
    sql.query("SELECT * FROM customers", (err, mysqlres) => {
        if (err) {
            console.log("error: ", err);
            res.status(400).send({ message: "error in getting all customers: " + err });
            return;
        }
        console.log("got all customers...");
        res.send(mysqlres);
        return;
    });
});
// Create new Customer
app.post("/CreateNewCustomer", CRUD_operations.createNewCustomer);
// get customer by name
app.get("/FindCustomersByName", CRUD_operations.FindCustomer);
// Update Customer
app.post('/update', CRUD_operations.UpdateCustomer);
// Delete a customer
app.delete('/removeCustomer', CRUD_operations.removeCustomer)
// Delete all customers
app.delete('/removeAll', CRUD_operations.removeAllCustomers)

// set port, listen for requests
app.listen(3000, () => {
    console.log("Server is running on port 3000."
    );
});
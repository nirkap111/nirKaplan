var sql = require('./db')
const createNewCustomer = function (req, res) {
    // Validate request
    if (!req.body) {
        res.status(400).send({
            message: "Content can not be empty!"
        });
        return;
    }
    const newCustomer = {
        "email": req.body.email,
        "name": req.body.name
    };
    sql.query("INSERT INTO customers SET ?", newCustomer, (err, mysqlres) => {
        if (err) {
            console.log("error: ", err);
            res.status(400).send({ message: "error in creating customer: " + err });
            return;
        }
        console.log("created customer: ", { id: mysqlres.insertId, ...newCustomer });
        res.send({ message: "new customer created successfully" });
        return;
    });
};
const FindCustomer = (req, res) => {
    // check if body is empty
    if (!req.body) {
        res.status(400).send({ message: "content can not be empty" });
        return;
    }
    //if body not empty - create new customer
    const Customer = req.query.FindName;
    console.log(Customer);
    //insert query
    sql.query("SELECT * FROM customers where name like ?", Customer + "%", (err, results,
        fields) => {
        if (err) {
            console.log("error is: " + err);
            res.status(400).send({ message: "error in finding customer " + err });
            return;
        }
        // if not query error
        console.log("new customer created ", createNewCustomer);
        res.send(results)
        //res.send({message: "new customer created successfully"});
        return;
    });
};
const UpdateCustomer = (req, res) => {
    // check if body is empty
    if (!req.body) {
        res.status(400).send({ message: "content can not be empty" });
        return;
    }
    var UpdateCustomer = {
        "email": req.body.NewCustomerEmail,
        "name": req.body.CustomerName
    };
    let query = "UPDATE customers set email = ? WHERE name = ?";
    let data = [UpdateCustomer.email, UpdateCustomer.name];
    // execute query
    sql.query(query, data, (err, results, fields) => {
        if (err) {
            console.log("error is: " + err);
            res.status(400).send({ message: "error in updating customer " + err });
            return;
        }
        console.log("rows effected ", results.affectedRows);
        res.send({ message: "rows effected " + results.affectedRows });
    });
};
const removeCustomer = (req, res) => {
    // check if body is empty
    if (!req.body) {
        res.status(400).send({ message: "content can not be empty" });
        return;
    }
    const name = req.body.name;
    let query = "DELETE FROM customers WHERE name = ?";
    let data = req.body.CustomerName;
    // execute query
    sql.query(query, data, (err, results, fields) => {
        if (err) {
            console.log("error is: " + err);
            res.status(400).send({ message: "error in removing customer " + err });
            return;
        }
        console.log("rows effected ", results.affectedRows);
        res.send({ message: "rows effected " + results.affectedRows });
    });
};
const removeAllCustomers = (req, res) => {
    let query = "DELETE FROM customers";
    // execute query
    sql.query(query, (err, results, fields) => {
        if (err) {
            console.log("error is: " + err);
            res.status(400).send({ message: "error in removing customers " + err });
            return;
        }
        console.log("rows affected ", results.affectedRows);
        res.send({ message: "all customers removed from database" });
    });
};




module.exports = { createNewCustomer, FindCustomer, UpdateCustomer, removeCustomer, removeAllCustomers };
